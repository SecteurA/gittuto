import React, { useState, useEffect } from 'react';
import { 
  DollarSign, 
  Calendar, 
  Search, 
  Download, 
  Filter,
  ChevronLeft,
  ChevronRight,
  Eye,
  Users,
  Building2,
  Truck,
  X,
  Printer
} from 'lucide-react';
import { supabase } from '../lib/supabase';

interface UnifiedPayment {
  id: string;
  type: 'client' | 'fournisseur' | 'chauffeur';
  entity_id: string;
  entity_name: string;
  entity_details: string;
  montant: number;
  mode_paiement: string;
  reference: string | null;
  issuer: string | null;
  date_paiement: string;
  notes: string | null;
}

const PaymentsList: React.FC = () => {
  const [payments, setPayments] = useState<UnifiedPayment[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [currentPage, setCurrentPage] = useState(1);
  const [itemsPerPage, setItemsPerPage] = useState(20);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPaymentType, setSelectedPaymentType] = useState<string>('');
  const [selectedPaymentMode, setSelectedPaymentMode] = useState<string>('');
  const [dateFilters, setDateFilters] = useState({
    dateFrom: '',
    dateTo: ''
  });
  
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [selectedPayment, setSelectedPayment] = useState<UnifiedPayment | null>(null);

  // For filter options
  const [filterOptions, setFilterOptions] = useState({
    paymentModes: ['cash', 'cheque', 'effet', 'virement'] as string[]
  });

  useEffect(() => {
    fetchPayments();
  }, []);

  const fetchPayments = async () => {
    try {
      setLoading(true);
      setError(null);

      // Fetch client payments
      const { data: clientPayments, error: clientError } = await supabase
        .from('paiements_clients')
        .select(`
          *,
          client:clients(nom, prenom, societe, numero_client)
        `)
        .order('date_paiement', { ascending: false });

      if (clientError) throw clientError;

      // Fetch supplier payments
      const { data: supplierPayments, error: supplierError } = await supabase
        .from('paiements_fournisseurs')
        .select(`
          *,
          fournisseur:fournisseurs(nom, prenom, societe, numero_fournisseur)
        `)
        .order('date_paiement', { ascending: false });

      if (supplierError) throw supplierError;

      // Fetch chauffeur payments
      const { data: chauffeurPayments, error: chauffeurError } = await supabase
        .from('paiements_chauffeurs')
        .select(`
          *,
          chauffeur:chauffeurs(nom, prenom, numero_chauffeur)
        `)
        .order('date_paiement', { ascending: false });

      if (chauffeurError) throw chauffeurError;

      // Unify all payments
      const unifiedPayments: UnifiedPayment[] = [
        // Client payments
        ...(clientPayments || []).map(payment => ({
          id: `client-${payment.id}`,
          type: 'client' as const,
          entity_id: payment.client_id,
          entity_name: payment.client.societe || `${payment.client.prenom} ${payment.client.nom}`,
          entity_details: `${payment.client.prenom} ${payment.client.nom} - ${payment.client.numero_client}`,
          montant: payment.montant,
          mode_paiement: payment.mode_paiement,
          reference: payment.reference,
          issuer: payment.issuer,
          date_paiement: payment.date_paiement,
          notes: payment.notes
        })),
        
        // Supplier payments
        ...(supplierPayments || []).map(payment => ({
          id: `fournisseur-${payment.id}`,
          type: 'fournisseur' as const,
          entity_id: payment.fournisseur_id,
          entity_name: payment.fournisseur.societe || `${payment.fournisseur.prenom} ${payment.fournisseur.nom}`,
          entity_details: `${payment.fournisseur.prenom} ${payment.fournisseur.nom} - ${payment.fournisseur.numero_fournisseur}`,
          montant: payment.montant,
          mode_paiement: payment.mode_paiement,
          reference: payment.reference,
          issuer: payment.issuer,
          date_paiement: payment.date_paiement,
          notes: payment.notes
        })),
        
        // Chauffeur payments
        ...(chauffeurPayments || []).map(payment => ({
          id: `chauffeur-${payment.id}`,
          type: 'chauffeur' as const,
          entity_id: payment.chauffeur_id,
          entity_name: `${payment.chauffeur.prenom} ${payment.chauffeur.nom}`,
          entity_details: `${payment.chauffeur.prenom} ${payment.chauffeur.nom} - ${payment.chauffeur.numero_chauffeur}`,
          montant: payment.montant,
          mode_paiement: payment.mode_paiement,
          reference: payment.reference,
          issuer: payment.issuer,
          date_paiement: payment.date_paiement,
          notes: payment.notes
        }))
      ];

      // Sort by date (most recent first)
      unifiedPayments.sort((a, b) => new Date(b.date_paiement).getTime() - new Date(a.date_paiement).getTime());

      setPayments(unifiedPayments);

      // Payment modes are now predefined
      setFilterOptions({
        paymentModes: ['cash', 'cheque', 'effet', 'virement']
      });

    } catch (err: any) {
      console.error('Error fetching payments:', err);
      setError('Erreur lors du chargement des paiements');
    } finally {
      setLoading(false);
    }
  };

  // Apply all filters
  const getFilteredPayments = () => {
    return payments.filter(payment => {
      // Text search filter
      const searchMatch = !searchTerm || (
        payment.entity_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        payment.entity_details.toLowerCase().includes(searchTerm.toLowerCase()) ||
        (payment.reference && payment.reference.toLowerCase().includes(searchTerm.toLowerCase())) ||
        (payment.issuer && payment.issuer.toLowerCase().includes(searchTerm.toLowerCase())) ||
        payment.mode_paiement.toLowerCase().includes(searchTerm.toLowerCase())
      );

      // Payment type filter
      const typeMatch = !selectedPaymentType || payment.type === selectedPaymentType;

      // Payment mode filter
      const modeMatch = !selectedPaymentMode || payment.mode_paiement === selectedPaymentMode;

      // Date range filter
      const dateMatch = (!dateFilters.dateFrom || payment.date_paiement >= dateFilters.dateFrom) &&
                       (!dateFilters.dateTo || payment.date_paiement <= dateFilters.dateTo);

      return searchMatch && typeMatch && modeMatch && dateMatch;
    });
  };

  const filteredPayments = getFilteredPayments();

  // Calculate pagination
  const totalPages = Math.ceil(filteredPayments.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentPayments = filteredPayments.slice(startIndex, endIndex);

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const handleItemsPerPageChange = (newItemsPerPage: number) => {
    setItemsPerPage(newItemsPerPage);
    setCurrentPage(1);
  };

  const handleDateFilterChange = (field: 'dateFrom' | 'dateTo', value: string) => {
    setDateFilters(prev => ({
      ...prev,
      [field]: value
    }));
    setCurrentPage(1);
  };

  const clearAllFilters = () => {
    setSearchTerm('');
    setSelectedPaymentType('');
    setSelectedPaymentMode('');
    setDateFilters({ dateFrom: '', dateTo: '' });
    setCurrentPage(1);
  };

  const hasActiveFilters = () => {
    return searchTerm || 
           selectedPaymentType || 
           selectedPaymentMode ||
           dateFilters.dateFrom || 
           dateFilters.dateTo;
  };

  const exportToCSV = () => {
    const csvHeaders = [
      'Date',
      'Type',
      'Entité',
      'Détails',
      'Montant (DH)',
      'Mode de Paiement',
      'Référence',
      'Émetteur',
      'Notes'
    ];

    const csvData = filteredPayments.map(payment => [
      new Date(payment.date_paiement).toLocaleDateString('fr-FR'),
      payment.type === 'client' ? 'Client' : 
      payment.type === 'fournisseur' ? 'Fournisseur' : 'Chauffeur',
      payment.entity_name,
      payment.entity_details,
      payment.montant.toFixed(2),
      payment.mode_paiement === 'cash' ? 'Espèces' :
      payment.mode_paiement === 'cheque' ? 'Chèque' :
      payment.mode_paiement === 'effet' ? 'Effet' :
      payment.mode_paiement === 'virement' ? 'Virement' : payment.mode_paiement,
      payment.reference || '',
      payment.issuer || '',
      payment.notes || ''
    ]);

    const csvContent = [csvHeaders, ...csvData]
      .map(row => row.map(cell => `"${cell}"`).join(','))
      .join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `paiements_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePaymentClick = (payment: UnifiedPayment) => {
    setSelectedPayment(payment);
    setShowPaymentModal(true);
  };

  const formatPrice = (price: number) => {
    return new Intl.NumberFormat('fr-MA', {
      minimumFractionDigits: 2,
      useGrouping: false
    }).format(price) + ' DH';
  };

  const getPaymentTypeBadge = (type: 'client' | 'fournisseur' | 'chauffeur') => {
    const typeConfig = {
      client: 'bg-green-100 text-green-800',
      fournisseur: 'bg-red-100 text-red-800',
      chauffeur: 'bg-blue-100 text-blue-800'
    };

    const typeLabel = {
      client: 'Client',
      fournisseur: 'Fournisseur',
      chauffeur: 'Chauffeur'
    };

    const typeIcon = {
      client: Users,
      fournisseur: Building2,
      chauffeur: Truck
    };

    const IconComponent = typeIcon[type];

    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium gap-1 ${typeConfig[type]}`}>
        <IconComponent className="w-3 h-3" />
        {typeLabel[type]}
      </span>
    );
  };

  const getPaymentModeBadge = (mode: string) => {
    const modeConfig = {
      cash: 'bg-green-100 text-green-800',
      cheque: 'bg-blue-100 text-blue-800',
      effet: 'bg-purple-100 text-purple-800',
      virement: 'bg-orange-100 text-orange-800'
    };

    const modeLabel = {
      cash: 'Espèces',
      cheque: 'Chèque',
      effet: 'Effet',
      virement: 'Virement'
    };

    return (
      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
        modeConfig[mode as keyof typeof modeConfig] || 'bg-gray-100 text-gray-800'
      }`}>
        {modeLabel[mode as keyof typeof modeLabel] || mode}
      </span>
    );
  };

  // Calculate totals for filtered data
  const calculateTotals = () => {
    const clientPayments = filteredPayments.filter(p => p.type === 'client');
    const supplierPayments = filteredPayments.filter(p => p.type === 'fournisseur');
    const chauffeurPayments = filteredPayments.filter(p => p.type === 'chauffeur');

    return {
      totalAmount: filteredPayments.reduce((sum, p) => sum + p.montant, 0),
      clientTotal: clientPayments.reduce((sum, p) => sum + p.montant, 0),
      supplierTotal: supplierPayments.reduce((sum, p) => sum + p.montant, 0),
      chauffeurTotal: chauffeurPayments.reduce((sum, p) => sum + p.montant, 0),
      count: filteredPayments.length,
      clientCount: clientPayments.length,
      supplierCount: supplierPayments.length,
      chauffeurCount: chauffeurPayments.length
    };
  };

  const totals = calculateTotals();

  if (loading) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-2"></div>
          <p className="text-gray-500">Chargement des paiements...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="h-full flex items-center justify-center">
        <div className="text-center">
          <p className="text-red-500 mb-4">{error}</p>
          <button
            onClick={fetchPayments}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg"
          >
            Réessayer
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-3">
            <DollarSign className="w-8 h-8 text-blue-600" />
            Paiements
          </h1>
          <p className="text-gray-600 mt-1">Vue d'ensemble de tous les paiements (clients, fournisseurs, chauffeurs)</p>
        </div>
        <div className="flex items-center gap-4">
          <button
            onClick={exportToCSV}
            className="bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 text-sm transition-colors duration-200"
          >
            <Download className="w-4 h-4" />
            Exporter CSV ({filteredPayments.length})
          </button>
          <button
            onClick={() => window.print()}
            className="bg-purple-600 hover:bg-purple-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 text-sm transition-colors duration-200"
          >
            <Printer className="w-4 h-4" />
            Imprimer ({filteredPayments.length})
          </button>
          <button
            onClick={fetchPayments}
            className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg flex items-center gap-2 text-sm transition-colors duration-200"
          >
            <Calendar className="w-4 h-4" />
            Actualiser
          </button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Total Paiements</p>
              <p className="text-2xl font-bold text-gray-900">{totals.count}</p>
              <p className="text-sm font-medium text-blue-600">{formatPrice(totals.totalAmount)}</p>
            </div>
            <DollarSign className="w-8 h-8 text-blue-600" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Clients</p>
              <p className="text-2xl font-bold text-green-600">{totals.clientCount}</p>
              <p className="text-sm font-medium text-green-600">{formatPrice(totals.clientTotal)}</p>
            </div>
            <Users className="w-8 h-8 text-green-600" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Fournisseurs</p>
              <p className="text-2xl font-bold text-red-600">{totals.supplierCount}</p>
              <p className="text-sm font-medium text-red-600">{formatPrice(totals.supplierTotal)}</p>
            </div>
            <Building2 className="w-8 h-8 text-red-600" />
          </div>
        </div>

        <div className="bg-white p-6 rounded-lg shadow-sm border border-gray-200">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600">Chauffeurs</p>
              <p className="text-2xl font-bold text-blue-600">{totals.chauffeurCount}</p>
              <p className="text-sm font-medium text-blue-600">{formatPrice(totals.chauffeurTotal)}</p>
            </div>
            <Truck className="w-8 h-8 text-blue-600" />
          </div>
        </div>
      </div>

      {/* Search Bar */}
      <div className="mb-6">
        <div className="relative">
          <Search className="w-5 h-5 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Rechercher par entité, référence, émetteur..."
            value={searchTerm}
            onChange={(e) => {
              setSearchTerm(e.target.value);
              setCurrentPage(1);
            }}
            className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
      </div>

      {/* Advanced Filters */}
      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 mb-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-semibold text-gray-900 flex items-center gap-2">
            <Filter className="w-5 h-5" />
            Filtres avancés
          </h3>
          {hasActiveFilters() && (
            <button
              onClick={clearAllFilters}
              className="text-red-600 hover:text-red-700 text-sm flex items-center gap-1 transition-colors duration-200"
            >
              <X className="w-4 h-4" />
              Effacer tous les filtres
            </button>
          )}
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Date Filters */}
          <div>
            <label htmlFor="date-from" className="block text-sm font-medium text-gray-700 mb-1">
              Date début
            </label>
            <input
              type="date"
              id="date-from"
              value={dateFilters.dateFrom}
              onChange={(e) => handleDateFilterChange('dateFrom', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
            />
          </div>
          
          <div>
            <label htmlFor="date-to" className="block text-sm font-medium text-gray-700 mb-1">
              Date fin
            </label>
            <input
              type="date"
              id="date-to"
              value={dateFilters.dateTo}
              onChange={(e) => handleDateFilterChange('dateTo', e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
            />
          </div>

          {/* Payment Type Filter */}
          <div>
            <label htmlFor="type-filter" className="block text-sm font-medium text-gray-700 mb-1">
              Type
            </label>
            <select
              id="type-filter"
              value={selectedPaymentType}
              onChange={(e) => {
                setSelectedPaymentType(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
            >
              <option value="">Tous les types</option>
              <option value="client">Clients</option>
              <option value="fournisseur">Fournisseurs</option>
              <option value="chauffeur">Chauffeurs</option>
            </select>
          </div>

          {/* Payment Mode Filter */}
          <div>
            <label htmlFor="mode-filter" className="block text-sm font-medium text-gray-700 mb-1">
              Mode de paiement
            </label>
            <select
              id="mode-filter"
              value={selectedPaymentMode}
              onChange={(e) => {
                setSelectedPaymentMode(e.target.value);
                setCurrentPage(1);
              }}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm"
            >
              <option value="">Tous les modes</option>
              {filterOptions.paymentModes.map((mode) => (
                <option key={mode} value={mode}>
                  {mode === 'cash' ? 'Espèces' :
                   mode === 'cheque' ? 'Chèque' :
                   mode === 'effet' ? 'Effet' :
                   mode === 'virement' ? 'Virement' : mode}
                </option>
              ))}
            </select>
          </div>

        </div>

        {hasActiveFilters() && (
          <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <div className="flex items-center justify-between">
              <p className="text-sm text-blue-800">
                <strong>{filteredPayments.length}</strong> paiement(s) trouvé(s) avec les filtres actifs
              </p>
              <p className="text-sm font-medium text-blue-900">
                Total filtré: {formatPrice(totals.totalAmount)}
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Table */}
      <div className="flex-1 bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-900 uppercase tracking-wider">
                  Date
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-900 uppercase tracking-wider">
                  Type
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-900 uppercase tracking-wider">
                  Entité
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-900 uppercase tracking-wider">
                  Montant
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-900 uppercase tracking-wider">
                  Mode
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-900 uppercase tracking-wider">
                  Référence
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-900 uppercase tracking-wider">
                  Émetteur
                </th>
                <th className="px-6 py-4 text-left text-xs font-semibold text-gray-900 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {currentPayments.length > 0 ? (
                currentPayments.map((payment) => (
                  <tr 
                    key={payment.id} 
                    onClick={() => handlePaymentClick(payment)}
                    className="hover:bg-gray-50 cursor-pointer transition-colors duration-150"
                  >
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {new Date(payment.date_paiement).toLocaleDateString('fr-FR')}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {getPaymentTypeBadge(payment.type)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">
                        {payment.entity_name}
                      </div>
                      <div className="text-sm text-gray-500">
                        {payment.entity_details}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <span className={payment.type === 'client' ? 'text-green-600' : 'text-red-600'}>
                        {payment.type === 'client' ? '+' : '-'}{formatPrice(payment.montant)}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {getPaymentModeBadge(payment.mode_paiement)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-mono">
                      {payment.reference || '-'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {payment.issuer || '-'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handlePaymentClick(payment);
                        }}
                        className="text-blue-600 hover:text-blue-900 flex items-center gap-1"
                      >
                        <Eye className="w-4 h-4" />
                        Détails
                      </button>
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={8} className="px-6 py-12 text-center text-gray-500">
                    <div className="flex flex-col items-center">
                      <DollarSign className="w-8 h-8 text-gray-300 mb-2" />
                      <p>{hasActiveFilters() ? 'Aucun paiement trouvé avec ces filtres' : 'Aucun paiement disponible'}</p>
                      {hasActiveFilters() && (
                        <button
                          onClick={clearAllFilters}
                          className="mt-2 text-blue-600 hover:text-blue-700 text-sm"
                        >
                          Effacer les filtres
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Pagination */}
      {totalPages > 1 && (
        <div className="mt-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="text-sm text-gray-600">
              Affichage de {startIndex + 1} à {Math.min(endIndex, filteredPayments.length)} sur {filteredPayments.length} paiements
            </div>
            <div className="flex items-center gap-2">
              <span className="text-sm text-gray-600">Éléments par page:</span>
              <select
                value={itemsPerPage}
                onChange={(e) => handleItemsPerPageChange(Number(e.target.value))}
                className="text-sm border border-gray-300 rounded px-2 py-1 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value={20}>20</option>
                <option value={50}>50</option>
                <option value={100}>100</option>
              </select>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrevPage}
              disabled={currentPage === 1}
              className="p-2 rounded-lg border border-gray-300 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            
            {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
              <button
                key={page}
                onClick={() => handlePageChange(page)}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors duration-200 ${
                  currentPage === page
                    ? 'bg-blue-600 text-white'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
              >
                {page}
              </button>
            ))}
            
            <button
              onClick={handleNextPage}
              disabled={currentPage === totalPages}
              className="p-2 rounded-lg border border-gray-300 hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors duration-200"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      )}

      {/* Payment Details Modal */}
      {showPaymentModal && selectedPayment && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-2xl w-full max-h-[90vh] overflow-hidden">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Détails du paiement</h3>
                <button
                  onClick={() => setShowPaymentModal(false)}
                  className="text-gray-400 hover:text-gray-600 transition-colors duration-200"
                >
                  <X className="w-6 h-6" />
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-6">
              {/* Payment Type Badge */}
              <div className="flex items-center gap-4">
                {getPaymentTypeBadge(selectedPayment.type)}
                <div className="text-2xl font-bold text-gray-900">
                  {selectedPayment.type === 'client' ? '+' : '-'}{formatPrice(selectedPayment.montant)}
                </div>
              </div>

              {/* Entity Information */}
              <div className="bg-gray-50 p-4 rounded-lg">
                <h4 className="font-medium text-gray-900 mb-2">
                  {selectedPayment.type === 'client' ? 'Client' : 
                   selectedPayment.type === 'fournisseur' ? 'Fournisseur' : 'Chauffeur'}
                </h4>
                <p className="text-lg font-semibold text-gray-900">{selectedPayment.entity_name}</p>
                <p className="text-sm text-gray-600">{selectedPayment.entity_details}</p>
              </div>

              {/* Payment Details Grid */}
              <div className="grid grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Date de paiement</label>
                  <p className="text-sm text-gray-900 bg-gray-50 px-3 py-2 rounded-lg">
                    {new Date(selectedPayment.date_paiement).toLocaleDateString('fr-FR', {
                      weekday: 'long',
                      year: 'numeric',
                      month: 'long',
                      day: 'numeric'
                    })}
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Mode de paiement</label>
                  <div className="bg-gray-50 px-3 py-2 rounded-lg">
                    {getPaymentModeBadge(selectedPayment.mode_paiement)}
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Référence</label>
                  <p className="text-sm text-gray-900 bg-gray-50 px-3 py-2 rounded-lg font-mono">
                    {selectedPayment.reference || 'Aucune référence'}
                  </p>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Émetteur</label>
                  <p className="text-sm text-gray-900 bg-gray-50 px-3 py-2 rounded-lg">
                    {selectedPayment.issuer || 'Non spécifié'}
                  </p>
                </div>
              </div>

              {/* Notes */}
              {selectedPayment.notes && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Notes</label>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <p className="text-sm text-gray-900">{selectedPayment.notes}</p>
                  </div>
                </div>
              )}

              {/* Transaction Summary */}
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <h4 className="font-medium text-blue-900 mb-2">Résumé de la transaction</h4>
                <div className="text-sm text-blue-800">
                  <p>
                    <strong>
                      {selectedPayment.type === 'client' ? 'Encaissement de' : 'Paiement à'} {selectedPayment.entity_name}
                    </strong>
                  </p>
                  <p className="mt-1">
                    Montant: <span className="font-semibold">{formatPrice(selectedPayment.montant)}</span> par {
                      selectedPayment.mode_paiement === 'cash' ? 'espèces' :
                      selectedPayment.mode_paiement === 'cheque' ? 'chèque' :
                      selectedPayment.mode_paiement === 'effet' ? 'effet' :
                      selectedPayment.mode_paiement === 'virement' ? 'virement bancaire' : selectedPayment.mode_paiement
                    }
                  </p>
                  {selectedPayment.reference && (
                    <p className="mt-1">Référence: <span className="font-mono">{selectedPayment.reference}</span></p>
                  )}
                </div>
              </div>
            </div>

            <div className="p-6 border-t border-gray-200">
              <button
                onClick={() => setShowPaymentModal(false)}
                className="w-full px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 font-medium transition-colors duration-200"
              >
                Fermer
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Print-only content */}
      <div className="hidden print:block fixed inset-0 bg-white p-8">
        {/* Print Header */}
        <div className="relative text-center border-b-2 border-gray-800 pb-6 mb-8">
          <img 
            src="https://pub-237d2da54b564d23aaa1c3826e1d4e65.r2.dev/ANTURGOOD/logo2.png" 
            alt="ANTURGOOD Logo" 
            className="absolute top-0 left-0 h-24 w-auto"
          />
          <p className="text-lg text-gray-700 mt-2">LISTE DES PAIEMENTS</p>
          <p className="text-lg text-gray-700 mt-2">
            {hasActiveFilters() ? 'Données filtrées' : 'Tous les paiements'}
          </p>
          <p className="text-sm text-gray-600 mt-2">
            Généré le {new Date().toLocaleDateString('fr-FR')} à {new Date().toLocaleTimeString('fr-FR')} | 
            {filteredPayments.length} paiement(s) | Total: {formatPrice(totals.totalAmount)}
          </p>
        </div>

        {/* Print Table */}
        <table className="w-full border-collapse border border-gray-800">
          <thead>
            <tr className="bg-gray-100">
              <th className="border border-gray-800 px-3 py-2 text-left font-semibold text-sm">Date</th>
              <th className="border border-gray-800 px-3 py-2 text-left font-semibold text-sm">Référence</th>
              <th className="border border-gray-800 px-3 py-2 text-left font-semibold text-sm">Entité</th>
              <th className="border border-gray-800 px-3 py-2 text-left font-semibold text-sm">Émetteur</th>
              <th className="border border-gray-800 px-3 py-2 text-right font-semibold text-sm">Montant</th>
            </tr>
          </thead>
          <tbody>
            {filteredPayments.map((payment) => (
              <tr key={payment.id}>
                <td className="border border-gray-800 px-3 py-2 text-sm">
                  {new Date(payment.date_paiement).toLocaleDateString('fr-FR')}
                </td>
                <td className="border border-gray-800 px-3 py-2 text-sm font-mono">
                  {payment.reference || '-'}
                </td>
                <td className="border border-gray-800 px-3 py-2 text-sm">
                  {payment.entity_name}
                </td>
                <td className="border border-gray-800 px-3 py-2 text-sm">
                  {payment.issuer || '-'}
                </td>
                <td className="border border-gray-800 px-3 py-2 text-sm text-right font-medium">
                  {formatPrice(payment.montant)}
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot className="bg-gray-100">
            <tr>
              <td className="border border-gray-800 px-3 py-3 font-bold text-sm" colSpan={4}>
                TOTAUX ({filteredPayments.length} paiements)
              </td>
              <td className="border border-gray-800 px-3 py-3 text-right font-bold text-sm">
                {formatPrice(totals.totalAmount)}
              </td>
            </tr>
          </tfoot>
        </table>

        {/* Print Footer */}
        <div className="absolute bottom-8 left-8 right-8 text-center text-xs text-gray-500 border-t border-gray-300 pt-4">
          <p>Document généré le {new Date().toLocaleDateString('fr-FR')} à {new Date().toLocaleTimeString('fr-FR')}</p>
        </div>
      </div>

      {/* Print Styles */}
      <style jsx>{`
        @media print {
          @page {
            margin: 1cm;
            size: A4 portrait;
          }
          
          body {
            -webkit-print-color-adjust: exact;
            color-adjust: exact;
          }
          
          /* Hide everything by default */
          body * {
            visibility: hidden;
          }
          
          /* Show only the print content */
          .print\\:block,
          .print\\:block * {
            visibility: visible;
          }
          
          /* Reset layout for print content */
          .print\\:block {
            position: absolute !important;
            left: 0 !important;
            top: 0 !important;
            width: 100% !important;
            height: 100% !important;
            margin: 0 !important;
            padding: 1cm !important;
            background: white !important;
            color: black !important;
            font-size: 12pt !important;
            line-height: 1.4 !important;
          }
          
          /* Table styling for print */
          table {
            border-collapse: collapse !important;
            width: 100% !important;
            font-size: 10pt !important;
          }
          
          th, td {
            border: 1px solid #000 !important;
            padding: 4px !important;
          }
          
          /* Page breaks */
          tbody tr {
            page-break-inside: avoid;
          }
          
          thead {
            display: table-header-group;
          }
          
          tfoot {
            display: table-footer-group;
            page-break-inside: avoid;
          }
          
          /* Hide any remaining UI elements */
          nav, aside, button:not(.print\\:block button), .print\\:hidden {
            display: none !important;
          }
        }
      `}</style>
    </div>
  );
};

export default PaymentsList;